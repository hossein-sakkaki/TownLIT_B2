﻿/*
 Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
 For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("uicolor","id",{title:"Pengambil  Warna UI",options:"Color Options",highlight:"Highlight",selected:"Selected Color",predefined:"Set warna belum terdefinisi.",config:"Tempel string ini ke arsip config.js anda."});