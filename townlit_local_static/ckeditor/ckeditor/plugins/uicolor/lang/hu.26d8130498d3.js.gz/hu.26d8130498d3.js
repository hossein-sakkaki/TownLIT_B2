﻿/*
 Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
 For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("uicolor","hu",{title:"UI Színválasztó",options:"Szín beállítások",highlight:"Kiemelés",selected:"Kiválasztott szín",predefined:"Előre definiált színbeállítások",config:"Illessze be ezt a szöveget a config.js fájlba"});