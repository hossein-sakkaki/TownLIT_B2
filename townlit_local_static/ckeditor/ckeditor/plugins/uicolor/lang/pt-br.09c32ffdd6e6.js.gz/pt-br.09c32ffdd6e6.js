﻿/*
 Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
 For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("uicolor","pt-br",{title:"Paleta de Cores",options:"Opções de cores",highlight:"Destaque",selected:"Cor Selecionada",predefined:"Conjuntos de cores predefinidos",config:"Cole o texto no seu arquivo config.js"});